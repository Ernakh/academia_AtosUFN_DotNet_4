export interface Pessoa {
    id?: number;
    nome: string;
}
